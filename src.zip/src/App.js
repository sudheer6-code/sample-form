import React, { useState } from 'react';
import './App.css'; // Import a CSS file for styling


function App() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    favoriteColor: '',
    hobbies: [],
    agreeToTerms: false,
  });

  const handleSubmit = (event) => {
    event.preventDefault();
    console.log('Form data:', formData);
  };

  const handleChange = (event) => {
    setFormData({ ...formData, [event.target.name]: event.target.value });
  };

  return (
    <form onSubmit={handleSubmit} className="form-container">
      <h2 className="form-title">User Information</h2>

      <div className="form-group">
        <label htmlFor="name" className="form-label">
          Name:
        </label>
        <input
          type="text"
          id="name"
          name="name"
          value={formData.name}
          onChange={handleChange}
          className="form-input"
        />
      </div>

      {/* ... (other fields with similar styling) */}

      <div className="form-group">
        <label className="form-label">
          Favorite Color:
        </label>
        <select
          value={formData.favoriteColor}
          onChange={handleChange}
          name="favoriteColor"
          className="form-input"
        >
          <option value="">Select a color</option>
          <option value="red">Red</option>
          <option value="blue">Blue</option>
          <option value="green">Green</option>
        </select>
      </div>

      <fieldset className="form-group">
        <legend>Hobbies:</legend>
        <label className="form-checkbox">
          <input
            type="checkbox"
            name="hobbies"
            value="reading"
            checked={formData.hobbies.includes('reading')}
            onChange={handleChange}
          />
          Reading
        </label>
        <label className="form-checkbox">
          <input
            type="checkbox"
            name="hobbies"
            value="coding"
            checked={formData.hobbies.includes('coding')}
            onChange={handleChange}
          />
          Coding
        </label>
        <label className="form-checkbox">
          <input
            type="checkbox"
            name="hobbies"
            value="music"
            checked={formData.hobbies.includes('music')}
            onChange={handleChange}
          />
          Music
        </label>
      </fieldset>

      <div className="form-group">
        <label className="form-label">Gender:</label>
        <label className="form-radio">
          <input
            type="radio"
            name="gender"
            value="male"
            checked={formData.gender === 'male'}
            onChange={handleChange}
          />
          Male
        </label>
        <label className="form-radio">
          <input
            type="radio"
            name="gender"
            value="female"
            checked={formData.gender === 'female'}
            onChange={handleChange}
          />
          Female
        </label>
      </div>

      <label className="form-checkbox">
        <input
          type="checkbox"
          name="agreeToTerms"
          checked={formData.agreeToTerms}
          onChange={handleChange}
        />
        I agree to the terms and conditions
      </label>

      <button type="submit" className="btn btn-primary">Submit</button>
    </form>
  );
}

export default App;


